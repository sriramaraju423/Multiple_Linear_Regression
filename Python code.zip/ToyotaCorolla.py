#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd


# In[7]:


ToyotaCorolla = pd.read_csv(r"C:\Users\srira\Desktop\Ram\Data science\Course - Assignments\Module 7 - Multiple Linear Regression\Dataset\ToyotaCorolla.csv", encoding= 'unicode_escape')
ToyotaCorolla.head(10)


# In[12]:


Corolla = ToyotaCorolla[["Price","Age_08_04","KM","HP","cc","Doors","Gears","Quarterly_Tax","Weight"]]
Corolla.head(10)


# In[ ]:


#Now we need to predict price


# ### EDA

# In[13]:


Corolla.isnull().sum()


# In[14]:


Corolla.corr()


# In[34]:


Corolla.describe()


# In[36]:


import seaborn as sb
sb.boxplot(x=Corolla.cc)


# In[15]:


#Let's draw pair plot and check whether their is linearity b/w independent varibales


# In[17]:


sb.pairplot(Corolla.iloc[:,:])


# In[18]:


#Most of the data seems fine. Except for Age vs KM. Let's try building model and check whether coefficients are significant


# In[20]:


import statsmodels.formula.api as smf
Corolla_model = smf.ols('Price ~ Age_08_04+KM+HP+cc+Doors+Gears+Quarterly_Tax+Weight', data = Corolla).fit()
Corolla_model.summary()


# In[21]:


#Doors&cc are not significant. And these two doesn't have any linear relationship


# In[22]:


#Let's try and do some tranformation and see whether these two variables can be made significant


# In[26]:


import numpy as np
Corolla_trans_model = smf.ols('Price ~ Age_08_04+KM+HP+np.log(cc)+np.log(Doors)+Gears+Quarterly_Tax+Weight', data = Corolla).fit()
Corolla_trans_model.summary()


# In[27]:


#Doors is still insignificant. Let's try and build only model with Doors to checks it relation with price


# In[28]:


Corolla_Doors_model = smf.ols('Price ~ Doors', data = Corolla).fit()
Corolla_Doors_model.summary()


# In[ ]:


#R2 value is too low. So i guess this variable can be removed


# In[29]:


#Even before removing any varible, let's try and check the influence plot and remove single observation, and try and findout if anything changes


# In[30]:


import matplotlib.pyplot as plt
import statsmodels.api as sm
sm.graphics.influence_plot(Corolla_trans_model)
plt.show()


# In[37]:


#Let's try and remove the three big outliers 80,221,960


# In[39]:


Corolla.drop(Corolla.index[[80,221,960]],inplace=True,axis=0)


# In[55]:


#building model after removing the unwanted data
Corolla_updated_model = smf.ols('Price ~ Age_08_04+KM+HP+cc+Doors+Gears+Quarterly_Tax+Weight', data = Corolla).fit()
Corolla_updated_model.summary()


# In[56]:


#Training and testing the model
from sklearn.model_selection import train_test_split
train_data,test_data = train_test_split(Corolla,test_size=0.3)


# In[57]:


#Building model with train and test data
Corolla_train_model = smf.ols('Price ~ Age_08_04+KM+HP+cc+Doors+Gears+Quarterly_Tax+Weight', data = train_data).fit()
Corolla_train_model.summary()


# In[58]:


Corolla_test_model = smf.ols('Price ~ Age_08_04+KM+HP+cc+Doors+Gears+Quarterly_Tax+Weight', data = test_data).fit()
Corolla_test_model.summary()


# In[ ]:


# R2 Train: 0.900 R2 Test: 0.855 -> Difference is less than 0.10 variance hence our model is perfect


# In[19]:


Corolla.columns

