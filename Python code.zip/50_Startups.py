#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd


# In[3]:


Startups = pd.read_csv(r"C:\Users\srira\Desktop\Ram\Data science\Course - Assignments\Module 7 - Multiple Linear Regression\Dataset\50_Startups.csv")
Startups.head(10)


# In[4]:


Startups = Startups.rename(columns={"R&D Spend":"RandD_Spend","Marketing Spend":"Marketing_Spend"})
Startups


# In[5]:


Startups.drop(columns='State', inplace=True)


# In[6]:


Startups.isnull().sum()


# In[7]:


Startups.corr()


# In[8]:


# Profit and R&D has very strong correlation


# In[9]:


import seaborn as sb
sb.pairplot(Startups.iloc[:,:])


# In[10]:


# Pair plot seems good for me as there is no strong correlation b/w independent variables


# In[11]:


import statsmodels.formula.api as smf
Startups_model = smf.ols('Profit~RandD_Spend+Administration+Marketing_Spend', data=Startups).fit()
Startups_model.summary()


# In[12]:


# Coefficient 'Administration' is insignificant
# checking variables 'Administration' and 'Marketing_Spend'
Startups_model_Marketing_Spend = smf.ols('Profit~Marketing_Spend', data=Startups).fit()
Startups_model_Marketing_Spend.summary()


# In[13]:


Startups_model_Administration = smf.ols('Profit~Administration', data=Startups).fit()
Startups_model_Administration.summary()


# In[14]:


Startups_model_Administration_Marketing = smf.ols('Profit~Administration+Marketing_Spend', data=Startups).fit()
Startups_model_Administration_Marketing.summary()


# In[15]:


# Majority of 'Profit' is heavily influenced by 'RandD_Spend'
#Let's try doing some transformation on other variables to see if anything changes
import numpy as np
Startups_model_trans = smf.ols('Profit~RandD_Spend+Administration+np.sqrt(Marketing_Spend)', data=Startups).fit()
Startups_model_trans.summary()


# In[16]:


# Let's try to do influence plot
import matplotlib.pyplot as plt
import statsmodels.api as sm
sm.graphics.influence_plot(Startups_model_trans)
plt.show()


# In[17]:


Startups_updated = Startups.drop(Startups.index[[19,45,46,48,49]], axis=0)
Startups_updated


# In[18]:


import numpy as np
Startups_model_trans = smf.ols('Profit~RandD_Spend+Administration+np.sqrt(Marketing_Spend)', data=Startups_updated).fit()
Startups_model_trans.summary()


# In[19]:


#let's try and find VIF values
# calculating VIF's values of independent variables
R2_RandD_Spend = smf.ols('RandD_Spend~Administration+Marketing_Spend',data=Startups_updated).fit().rsquared
VIF_RandD_Spend = 1/(1-R2_RandD_Spend)
VIF_RandD_Spend

R2_Administration = smf.ols('Administration~RandD_Spend+Marketing_Spend',data=Startups_updated).fit().rsquared
VIF_Administration = 1/(1-R2_Administration)

R2_Marketing_Spend = smf.ols('Marketing_Spend~Administration+RandD_Spend',data=Startups_updated).fit().rsquared
VIF_Marketing_Spend = 1/(1-R2_Marketing_Spend)
VIF_Marketing_Spend


# In[20]:


d1 = {'Variables':['RandD_Spend','Administration','Marketing_Spend'],'VIF':[VIF_RandD_Spend,VIF_Administration,VIF_Marketing_Spend]}
VIF_frame = pd.DataFrame(d1)
VIF_frame


# In[21]:


#High VIF implies Worst variable - This proves 'Administration' can't be removed


# In[22]:


# For cross checking let's check added variable or partial regression plot
sm.graphics.plot_partregress_grid(Startups_model_trans)
plt.show()


# In[23]:


#It's quite evident that added variable plot or partial regression plot doesn't say Administration as culprit


# In[24]:


# So from my perspective, we need not remove the 'Administration' variable. Let's try and remove and see it it makes any significant difference


# In[25]:


# even before trying new model let's find RMSE of current model
Startups_model_trans_pred = Startups_model_trans.predict(Startups_updated)
Startups_model_trans_pred


# In[26]:


error = Startups_updated['Profit'] - Startups_model_trans_pred
rmse = np.sqrt(np.mean(np.square(error)))
rmse


# In[27]:


#Now building model without 'Administration'
Startups_model_trans_rm = smf.ols('Profit~RandD_Spend+Marketing_Spend', data=Startups_updated).fit()
Startups_model_trans_rm.summary()


# In[28]:


Startups_model_trans_rm_pred = Startups_model_trans_rm.predict(Startups_updated)
Startups_model_trans_rm_pred


# In[29]:


error = Startups_updated['Profit'] - Startups_model_trans_rm_pred
rmse = np.sqrt(np.mean(np.square(error)))
rmse


# In[30]:


# There is much difference b/w RMSE with respect to models. So i prefer to go with model-trans


# In[31]:


#plots with 'Startups_model_trans' model
#fitted values vs observed values
plt.scatter(Startups_model_trans_pred,Startups_updated['Profit']);plt.xlabel("fitted values");plt.ylabel("observed values")


# In[32]:


#fitted values vs standardized residuals
plt.scatter(Startups_model_trans_pred,Startups_model_trans.resid_pearson);plt.axhline(y=0,color='r');plt.xlabel("fitted values");plt.ylabel("standardized residuals")


# In[33]:


# i guess there is some issue from plot


# In[34]:


plt.hist(Startups_model_trans.resid_pearson)


# In[35]:


import pylab
import scipy.stats as st
st.probplot(Startups_model_trans.resid_pearson, dist="norm", plot=pylab)


# In[36]:


# The distribution doesn't look perfect so let's try and plot model without 'Administration'
plt.scatter(Startups_model_trans_rm_pred,Startups_updated['Profit']);plt.xlabel('Fitted values');plt.ylabel('Observed values')


# In[38]:


plt.scatter(Startups_model_trans_rm_pred,Startups_model_trans_rm.resid_pearson);plt.axhline(y=0,color='r');plt.xlabel('Fitted values');plt.ylabel('Standard residuals')


# In[39]:


plt.hist(Startups_model_trans_rm.resid_pearson)


# In[40]:


st.probplot(Startups_model_trans_rm.resid_pearson, dist='norm', plot=pylab)


# In[37]:


Startups.columns

