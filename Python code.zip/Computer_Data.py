#!/usr/bin/env python
# coding: utf-8

# In[73]:


import pandas as pd
import numpy as np


# In[74]:


Computer_Data = pd.read_csv(r"C:\Users\srira\Desktop\Ram\Data science\Course - Assignments\Module 7 - Multiple Linear Regression\Dataset\Computer_Data.csv")
Computer_Data.head(10)


# In[75]:


#removing the unwanted data
Computer_Data.drop(Computer_Data.columns[0],inplace=True,axis=1)
Computer_Data.head(10)


# In[76]:


#For this particular dataset, we don't have any sales i.e. no upfront Y given we need to findout y


# ## EDA

# In[77]:


#checking for null values
Computer_Data.isnull().sum()


# In[78]:


#need to replace with dummy variables
# Computer_Data['cd'].replace(to_replace = {'Yes': 1, 'No':0}, inplace=True)
Computer_Data['cd'] = Computer_Data['cd'].eq('yes').mul(1)
Computer_Data['multi'] = Computer_Data['multi'].eq('yes').mul(1)
Computer_Data['premium'] = Computer_Data['premium'].eq('yes').mul(1)


# In[79]:


Computer_Data.head(10)


# In[80]:


#Output variable is to predict 'sales'. Price is proportional to sales. Hence output variable is mostly price


# In[81]:


Computer_Data.trend.value_counts()


# In[87]:


np.corrcoef(np.log(Computer_Data.speed),np.log(Computer_Data.price))


# In[83]:


#Let's draw pairplot to check any co_linearity
import seaborn as sb
sb.pairplot(Computer_Data.iloc[:,:])


# In[103]:


#Building model
import statsmodels.formula.api as smf
Computer_Data_model = smf.ols('price~np.log(speed)+np.log(hd)+ram+np.log(screen)+cd+multi+premium+ads+trend', data=Computer_Data).fit()
Computer_Data_model.summary()


# In[ ]:


#All the coefficients are significant and R2 is pretty decent hence we can go ahead and finalize this model


# In[ ]:


#Now let's try and check any of the variables are not required for model building


# In[107]:


import matplotlib.pylab as plt
import statsmodels.api as sm
sm.graphics.influence_plot(Computer_Data_model)
plt.show()


# In[109]:


#Train and test
from sklearn.model_selection import train_test_split
train_data,test_data = train_test_split(Computer_Data, test_size=0.3)

Computer_Data_train_model = smf.ols('price~np.log(speed)+np.log(hd)+ram+np.log(screen)+cd+multi+premium+ads+trend', data=train_data).fit()
Computer_Data_train_model.summary()


# In[110]:


Computer_Data_test_model = smf.ols('price~np.log(speed)+np.log(hd)+ram+np.log(screen)+cd+multi+premium+ads+trend', data=test_data).fit()
Computer_Data_test_model.summary()


# In[111]:


pred = Computer_Data_model.predict()


# In[112]:


#Let's find RMSE
error = Computer_Data.price - pred
rmse = np.sqrt(np.mean(np.square(error)))
rmse


# In[85]:


Computer_Data.columns

